
# References:

[Code forces starting competitive programming](http://codeforces.com/blog/entry/23054)

[Algorithm Wiki](http://wcipeg.com/wiki/Special:AllPages)
