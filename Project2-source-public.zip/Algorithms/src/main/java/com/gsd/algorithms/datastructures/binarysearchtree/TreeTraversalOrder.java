package com.gsd.algorithms.datastructures.binarysearchtree;

public enum TreeTraversalOrder {
  PRE_ORDER,
  IN_ORDER,
  POST_ORDER,
  LEVEL_ORDER
}
