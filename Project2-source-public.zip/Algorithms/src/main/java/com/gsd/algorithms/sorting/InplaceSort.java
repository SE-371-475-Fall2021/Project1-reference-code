package com.gsd.algorithms.sorting;

// A shared interface amongst sorting algorithms which
public interface InplaceSort {
  public void sort(int[] values);
}
