/**
 * Simple interface file for double hashing
 *
* SE371/475 Global Software Dev - Project 1 - Unit Testing
 */
package com.gsd.algorithms.datastructures.hashtable;

public interface SecondaryHash {

  // A method for a second hash function
  public int hashCode2();
}
